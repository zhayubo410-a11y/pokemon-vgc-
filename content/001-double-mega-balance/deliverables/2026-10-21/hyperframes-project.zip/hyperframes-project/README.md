# 重装肉坦暴飞龙：无声视频工程

使用 HyperFrames 0.8.183，1920×1080，30 fps，28 段画面（26 张独立画面），时间轴 588.990 秒。按已确认的 narration-tight-v3.srt 切换，保留间隙中的上一张画面。不含音轨，不烧录字幕；SRT 可在剪辑软件中单独导入。

本工程由已确认 HTML 源数据转换，所有图片、GSAP 3.14.2、中文字体均在本地。原审阅稿未修改。前置引用 R12 和 R21 时按已确认规划淡化非当前讲述区域。

```sh
npx hyperframes@0.8.183 render . --fps 30 --quality delivery --workers 1 --output renders/pokemon-vgc-silent.mp4
```

根时间轴规定成片时长；开头的 0.001 秒对象 tween 仅用于注册可寻址时间轴。之后画面静止，HyperFrames 可校验并复用静止帧。切换时间以 30 fps 量化，误差不超过一帧。MP4 时长向上取整为 589 秒。

图片来自已审阅项目素材；字体为 Noto Sans CJK SC（SIL Open Font License）。

本次静止帧优化使用 HF_STATIC_DEDUP_VERIFY=false（已独立审阅全部画面）；单 worker 连续捕获可复用前一帧。默认命令仍会做工具自身的静止帧抽检。
